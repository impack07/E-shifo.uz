<!doctype html>
<!--[if IE 7]>    <html class="ie7" > <![endif]-->
<!--[if IE 8]>    <html class="ie8" > <![endif]-->
<!--[if IE 9]>    <html class="ie9" > <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en-US"> <!--<![endif]-->
		<head>				
				<!-- META TAGS -->
				<meta charset="UTF-8" />
				<meta name="viewport" content="width=device-width" />
				
				<!-- Title -->
				<title>Health Press</title>
              
                <!-- FAVICON -->
                <link rel="shortcut icon" href="temp_class/images/favicon.png.png" />
				
                
                <!-- Style Sheet-->
				<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,800,700,300' rel='stylesheet' type='text/css'>
				<link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>                  
                <link rel="stylesheet" href="temp_class/js/prettyPhoto/css/prettyPhoto.css"/>
                <link rel="stylesheet" href="temp_class/js/flexslider/flexslider.css"/>                
                <link rel="stylesheet" href="temp_class/css/jquery.ui.all.css"/>                
                <link rel="stylesheet" href="temp_class/css/jquery.ui.theme.css"/> 
				<link rel="stylesheet" href="temp_class/css/font-awesome.min.css"/> 				<link rel="stylesheet" href="style.css"/>
                <link rel="stylesheet" href="temp_class/css/media-queries.css"/>                    
                <link rel="stylesheet" href="temp_class/css/custom.css"/>                     
                
                <!-- Pingback URL -->
                <link rel="pingback" href="http://healthpress.inspirythemes.com/xmlrpc.php" />

                <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
                <!--[if lt IE 9]>
                    <script src="js/html5.js"></script>
                <![endif]-->
				
		</head>
        
        <body>				
        
				<!-- Starting Website Wrapper -->
                <div id="wrapper">
                		
                        <!-- Starting Header of the website -->
                        <?php include('header.php');?>
                        
                        							
                        
                        <hgroup class="page-head">     		
                                <h2>Our <span>Doctors</span></h2>
                                <h5>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy <br>nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</h5>
                        </hgroup>
                        
                        <div id="container">
                        
                                <div class="page_featured">													
                                        <img src="temp_class/images/Refined/doctors-image.jpeg" alt="2 Columns Doctors">                                                               												
                                </div>
                                        
									<article id="post-id" class="clearfix">
                                    	<!--<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</p>-->
                                    </article>
                                
                                <section class="doc_list four_col clearfix">
                                	
										<ul class="doctors clearfix">	
                                                <li>
                                                	<figure class="doc-img">													
														<a href="#" title="Dr.Orana Taleebin"><img src="temp_class/images/Refined/d1.jpeg" alt="Dr.Orana Taleebin"></a>																			<span class="doc-type"><a href="#">Gyne</a></span>																																
													</figure>
													 <h4><a href="#">Dr.Orana Taleebin</a></h4>
                                                     <p>Royal Prince Alfred Hospital – Sydney June 2009 to July 2010 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed…</p>
                                                     <a href="#" class="readmore">More</a>
                                                </li>                                               
													
                                                <li>
                                                    <figure class="doc-img">													
                                                        <a href="#" title="Dr.Adaline Becka"><img src="temp_class/images/Refined/d2.jpeg" alt="Dr.Adaline Becka"></a>																			<span class="doc-type"><a href="#">Gyne</a></span>																																
                                                    </figure>
                                                    <h4><a href="#">Dr.Adaline Becka</a></h4>
                                                    <p>Royal Prince Alfred Hospital – Sydney June 2009 to July 2010 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed…</p>
                                                    <a href="#" class="readmore">More</a>
                                                </li>                                               
													
                                                <li>
                                                    <figure class="doc-img">													
                                                        <a href="#" title="Dr.Andrew Bert"><img src="temp_class/images/Refined/d3.jpeg" alt="Dr.Andrew Bert"></a>																			<span class="doc-type"><a href="#">ENT</a></span>																																
                                                    </figure>
                                                    <h4><a href="#">Dr.Andrew Bert</a></h4>
                                                    <p>Royal Prince Alfred Hospital – Sydney June 2009 to July 2010 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed…</p>
                                                    <a href="#" class="readmore">More</a>
                                                </li>                                               
													
                                                <li>
                                                    <figure class="doc-img">													
                                                    	<a href="#" title="Dr.Kylee Leewan"><img src="temp_class/images/Refined/d5.jpeg" alt="Dr.Kylee Leewan"></a>																			<span class="doc-type"><a href="#">Gyne</a></span>																																
                                                    </figure>
                                                    <h4><a href="#">Dr.Kylee Leewan</a></h4>
                                                    <p>Royal Prince Alfred Hospital – Sydney June 2009 to July 2010 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed…</p>
                                                    <a href="#" class="readmore">More</a>
                                                </li>                                               
										</ul>
                                        <ul class="doctors clearfix">   
                                                <li>
                                                    <figure class="doc-img">                                                    
                                                        <a href="#" title="Dr.Orana Taleebin"><img src="temp_class/images/Refined/d4.jpeg" alt="Dr.Orana Taleebin"></a>                                                                         <span class="doc-type"><a href="#">Gyne</a></span>                                                                                                                              
                                                    </figure>
                                                     <h4><a href="#">Dr.Orana Taleebin</a></h4>
                                                     <p>Royal Prince Alfred Hospital – Sydney June 2009 to July 2010 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed…</p>
                                                     <a href="#" class="readmore">More</a>
                                                </li>                                               
                                                    
                                                <li>
                                                    <figure class="doc-img">                                                    
                                                        <a href="#" title="Dr.Adaline Becka"><img src="temp_class/images/Refined/d3.jpeg" alt="Dr.Adaline Becka"></a>                                                                           <span class="doc-type"><a href="#">Gyne</a></span>                                                                                                                              
                                                    </figure>
                                                    <h4><a href="#">Dr.Adaline Becka</a></h4>
                                                    <p>Royal Prince Alfred Hospital – Sydney June 2009 to July 2010 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed…</p>
                                                    <a href="#" class="readmore">More</a>
                                                </li>                                               
                                                    
                                                <li>
                                                    <figure class="doc-img">                                                    
                                                        <a href="#" title="Dr.Andrew Bert"><img src="temp_class/images/Refined/d5.jpeg" alt="Dr.Andrew Bert"></a>                                                                           <span class="doc-type"><a href="#">ENT</a></span>                                                                                                                               
                                                    </figure>
                                                    <h4><a href="#">Dr.Andrew Bert</a></h4>
                                                    <p>Royal Prince Alfred Hospital – Sydney June 2009 to July 2010 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed…</p>
                                                    <a href="#" class="readmore">More</a>
                                                </li>                                               
                                                    
                                                <li>
                                                    <figure class="doc-img">                                                    
                                                        <a href="#" title="Dr.Kylee Leewan"><img src="temp_class/images/Refined/d1.jpeg" alt="Dr.Kylee Leewan"></a>                                                                         <span class="doc-type"><a href="#">Gyne</a></span>                                                                                                                              
                                                    </figure>
                                                    <h4><a href="#">Dr.Kylee Leewan</a></h4>
                                                    <p>Royal Prince Alfred Hospital – Sydney June 2009 to July 2010 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed…</p>
                                                    <a href="#" class="readmore">More</a>
                                                </li>                                               
                                        </ul>
										
                                        
                                        <div id="pagination"><a href="#" class="readmore current">1</a> <a href="#" class="readmore">2</a></div>
										                                                                               
                                </section>
                                                                                                                 
                          <!-- twitter update list -->
                            

                        </div><!-- end of container -->
                        
                                       
                                              
                       
                      
						<div id="footer-bottom-wrapper">
                            <div id="footer-bottom">
                                    <p class="copyrights">© OpenData Challenge.</p>
                                     
                            </div><!-- footer-bottom -->
                        </div>
                        
                </div><!-- End of Wrapper Div -->
				
                <script src="temp_class/js/jquery-2.2.3.min.js"></script><script src="js/jquery-migrate-1.3.0.js"></script>
                <script src="temp_class/js/prettyPhoto/js/jquery.prettyPhoto.js"></script>                
                <script src="temp_class/js/jquery.validate.min.js"></script>
                <script src="temp_class/js/jquery.form.js"></script>
                <script src="temp_class/js/jquery.ui.core.min.js"></script>
                <script src="temp_class/js/jquery.ui.datepicker.min.js"></script>
                <script src="temp_class/js/jquery.cycle.lite.js"></script>
                <script src="temp_class/js/jquery.easing.1.3.js"></script>
                <script src="temp_class/js/jquery-twitterFetcher.js"></script>
                <script src="temp_class/js/flexslider/jquery.flexslider-min.js"></script>
                <script src="temp_class/js/jquery.isotope.min.js"></script>
                
                <script src="temp_class/js/custom.js"></script>

				<a href="#top" id="scroll-top"></a>
                	
		</body>
</html>	          
              