<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "opendata";
$conn = mysqli_connect($servername, $username, $password, $dbname);
?>