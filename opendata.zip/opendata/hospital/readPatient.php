<?php
  // http://localhost/opendata/hospital_1/hospital/read.php?email=".$name;
header("Content-Type:application/json");
include_once("baza.php");
if(!empty($_GET['email'])) {
$email=$_GET['email'];
$items = getItems($email, $conn);
if(empty($items)) {
jsonResponse(200,"Items Not Found",NULL);
} else {
jsonResponse(200,"Item Found",$items);
}
} else {
jsonResponse(400,"Invalid Request",NULL);
}

$response = array();
 
 //if it is an api call 
 //that means a get parameter named api call is set in the URL 
 //and with this parameter we are concluding that it is an api call 
 if(isset($_GET['apicall'])){
 
 switch($_GET['apicall']){
 
 case 'signup':
 
 //in this part we will handle the registration
 
 break; 
 
 case 'login':
 
 //this part will handle the login 
 
 break; 
 
 default: 
 $response['error'] = true; 
 $response['message'] = 'Invalid Operation Called';
 }
 
 }else{
 //if it is not api call 
 //pushing appropriate values to response array 
 $response['error'] = true; 
 $response['message'] = 'Invalid API Call';
 }




function jsonResponse($status,$status_message,$data) {
header("HTTP/1.1 ".$status_message);
$response['status']=$status;
$response['status_message']=$status_message;
$response['data']=$data;
$json_response = json_encode($response);
echo $json_response;
}
function getItems($email, $conn) {
$sql = "SELECT id, u.fullName, u.address, u.city, u.gender,u.regDate FROM users u WHERE u.user_signature LIKE '".md5($email)."'";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$data = array();
while( $rows = mysqli_fetch_assoc($resultset) ) {
$data[] = $rows;
}
return $data;
}
 print_r($items); 


?>