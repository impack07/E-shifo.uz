<?php
session_start();
  // http://localhost/opendata/hospital/readDrug_list.php?drug_id=u1410008@gmail.com&drug_date=02/12/2018&drug_by_doctor=5
header("Content-Type:application/json");
include_once("baza.php");
if(!empty($_GET['drug_id']) && !empty($_GET['drug_date']) && !empty($_GET['drug_by_doctor'])) {
$drug_id=md5($_GET['drug_id']);
$drug_date=$_GET['drug_date'];
$drug_by_doctor=$_GET['drug_by_doctor'];
$items = getItems($drug_id,$drug_date,$drug_by_doctor, $conn);
if(empty($items)) {
jsonResponse(200,"Items Not Found",NULL);
} else {
jsonResponse(200,"Item Found",$items);
}
} else {
jsonResponse(400,"Invalid Request",NULL);
}
function jsonResponse($status,$status_message,$data) {
header("HTTP/1.1 ".$status_message);
$response['status']=$status;
$response['status_message']=$status_message;
$response['data']=$data;
$json_response = json_encode($response);
echo $json_response;
}
function getItems($drug_id,$drug_date,$drug_by_doctor, $conn) {
$sql = "SELECT * FROM  drug_list WHERE dori_to='".$drug_id."' AND dori_post_date='".$drug_date."' AND dori_by='".$drug_by_doctor."'";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$data = array();
while( $rows = mysqli_fetch_assoc($resultset) ) {
$data[] = $rows;
}
return $data;
}
 print_r($items); 


?>