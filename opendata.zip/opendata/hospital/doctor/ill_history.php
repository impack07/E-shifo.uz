<?php
session_start();
//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();

if(isset($_GET['num'])){
			
			$ill_id=$_GET['num'];   //  ill_id to collect all data from `ill_history` table
			
			$sql_ill_history=mysql_query("select * from ill_history where byPatient_id='$ill_id'"); //  ill history

			$sql_drug_list=mysql_query("select * from drug_list where dori_to='$ill_id' AND dori_by='".$_SESSION['id']."' ");// drug_list


}
else
{
	echo 'fail';
	//header('location:dashboard.php');
}


if(isset($_POST['submit'])){

	$ill_id=$_GET['num'];
	$ill_text=$_POST['history'];
	$ill_status=$_POST['ill_status'];
	$date=$_POST['ill_date'];

	$post_date=date("d/m/Y");





	$query=mysql_query("insert into ill_history(ill_text,ill_type,treat_time,byPatient_id,byDoctor_id,post_date) values('$ill_text','$ill_status','$date','$ill_id','".$_SESSION['id']."','$post_date')");
	if($query)
	{
		echo "<script>window.location.href = 'ill_history.php?num=".$_GET['num']."';</script>";
		//header("Location: appointment-history.php");
	}
}

if(isset($_POST['dori_submit']))
	{
	    
			    $dori_to=$_GET['num'];
				$dori_nomi=$_POST['dori_nomi'];
				$dori_times=$_POST['dori_times'];
				$dori_during=$_POST['dori_during'];
				$dori_post_date=date("d/m/Y");

				$dori_by=$_SESSION['id'];




				$query=mysql_query("insert into drug_list(dori_to,dori_nomi,dori_times,dori_during,dori_post_date,dori_by) values('$dori_to','$dori_nomi','$dori_times','$dori_during','$dori_post_date','$dori_by')");
	if($query)
	{
		echo "<script>window.location.href = 'ill_history.php?num=".$_GET['num']."';</script>";

		//header("Location: appointment-history.php");
	}
				

	}





?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Доктор  | Kasallik tarixi</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta content="" name="description" />
		<meta content="" name="author" />
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
		<link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />

		<!-- MODAL -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- modal -->
	</head>
	<body>
		<div id="app">		
<?php include('include/sidebar.php');?>
			<div class="app-content">
				
						<?php include('include/header.php');?>
						
				<!-- end: TOP NAVBAR -->
				<div class="main-content" >
					<div class="wrap-content container" id="container">
						<!-- start: PAGE TITLE -->
						<section id="page-title">
							<div class="row">
								<div class="col-sm-8">
									<h1 class="mainTitle">Доктор  | Kasallik tarixi</h1>
																	</div>
								<ol class="breadcrumb">
									<li>
										<span>Доктор</span>
									</li>
									<li class="active">
										<span>Kasallik tarixi</span>
									</li>
								</ol>
							</div>
						</section>
						<!-- end: PAGE TITLE -->
						<!-- start: BASIC EXAMPLE -->
							<div class="container-fluid container-fullw bg-white">
							<div class="row">
									<div class="col-sm-8">

								<table class="table table-hover" id="sample-table-1">
										<thead>
											<tr>
												<th class="center">#</th>
												<th>Post Date</th>
												<th class="hidden-xs">Kasallik tarixi</th>
												<th>Bemorning xolati</th>
												<th>Keyingi muolaja<br> vaqti</th>
												<!-- <th>Kim tomonidan</th> -->
												
												
												
											</tr>
										</thead>
										<tbody>

					<?php	$count=1;   
while($row=mysql_fetch_array($sql_ill_history))
{
?>
											<tr>
												<td class="center"><?php echo $count;?>.</td>
												<td><?php echo $row['post_date'];?></td>
												<td class="hidden-xs" ><?php echo $row['ill_text'];?></td>
												<td><?php 
												if( $row['ill_type']==1){
													echo '<b style="color:green;">Boshlanich</b>';
												}
												else if( $row['ill_type']==2){
													echo '<b style="color:grey;">Orta</b>';
												}
												else if( $row['ill_type']==3){
													echo '<b style="color:red;">Ogir</b>';
												}
												
												?></td>
												<td><?php echo $row['treat_time'];?></td>
												<!-- <td><?php echo $row['byDoctor_id'];?></td> -->
												
												
											</tr>
<?php 
$count=$count+1;
											 }?>
										</tbody>
						</table>
								
								</div>

								<div class="col-sm-4" align="center">
									<form action="" method="post">
										
<br>
  <div class=""><label for="exampleFormControlTextarea1"><h3><b>Kasallik haqida</b></h3></label>
    <textarea class="form-control" id="exampleFormControlTextarea1" name="history" rows="10" placeholder="Yozing..."></textarea>
  <br>
			<div align="left">
			 <h4><b>Hozirgi xolati:</b></h4><b style="color:green;">Boshlang'ich</b> &nbsp;<input type="radio" name="ill_status" value="1" required="required">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			  	<b style="color:grey;">O'rta</b> &nbsp;<input type="radio" name="ill_status" value="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			  	<b style="color:red;">Jiddiy</b> &nbsp;<input type="radio" name="ill_status" value="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			  	
			</div>

<br>
			<div align="left">
				<h4><b>Keyingi muolaja vaqti:  </b><input type="date" required="" name="ill_date"></h4>
				<input type="submit" name="submit" value="Saqlash" class="btn btn-success">
			</div>
			
  </div>


									</form>
								</div>
							</div>

			
						</div>
			   <div class="container">
  
  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Dorilarni Qo'shish</button>
<hr><h3>Bemorga tavsiya qilingan dorilar ro'yxati</h3>
<div class="col-sm-8">
  						<table class="table table-hover" id="sample-table-1">
										<thead>
											<tr>
												<th class="center">#</th>
												<th>Dori Nomi</th>
												<th class="hidden-xs">Kundlik<br> qo'llanishi</th>
												<th>Kun davomida</th>
											</tr>
										</thead>
										<tbody>

				<?php	$count_dori=1;   
while($row=mysql_fetch_array($sql_drug_list))
{
?>
											<tr>
												<td class="center"><?php echo $count;?>.</td>
												<td><?php echo $row['dori_nomi'];?></td>
												<td class="hidden-xs" ><?php echo $row['dori_times'];?></td>
												<td class="hidden-xs" ><?php echo $row['dori_during'];?></td>
											</tr>
<?php 
$count_dori=$count_dori+1;
											 }?>
										</tbody>
						</table>

</div>
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <form action="" method="post">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Dori haqida batafsil</h4>
        </div>
        <div class="modal-body">
          
          	<input type="text" class="form-control" name="dori_nomi" placeholder="Dori nomi"><br>
          	<input type="text" class="form-control" name="dori_times" placeholder="Qo'llash kundalik tartibi"><br>
          	<input type="text"  class="form-control" name="dori_during" placeholder="Kun mobaynida"><br>
          	
         
        </div>

        <div class="modal-footer">
          <input type="submit" name="dori_submit" class="btn btn-success" value="Qo'shish">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
       </form>
    </div>
  </div>
  
</div>
					
					
						
						
					
						<!-- end: SELECT BOXES -->
						
					</div>

				</div>
			</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			<>
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
