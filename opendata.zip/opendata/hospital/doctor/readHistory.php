<?php
  // http://localhost/opendata/hospital_1/hospital/read.php?email=".$name;
header("Content-Type:application/json");
include_once("../baza.php");
if(!empty($_GET['ill'])) {
$ill=md5($_GET['ill']);
$items = getItems($ill, $conn);
if(empty($items)) {
jsonResponse(200,"Items Not Found",NULL);
} else {
jsonResponse(200,"Item Found",$items);
}
} else {
jsonResponse(400,"Invalid Request",NULL);
}
function jsonResponse($status,$status_message,$data) {
header("HTTP/1.1 ".$status_message);
$response['status']=$status;
$response['status_message']=$status_message;
$response['data']=$data;
$json_response = json_encode($response);
echo $json_response;
}
function getItems($ill, $conn) {
$sql = "SELECT i.id, i.post_date, i.ill_text, i.ill_type, i.byDoctor_id,i.byPatient_id,i.treat_time,d.doctorName,d.address,d.contactno,d.docEmail,u.fullName,u.address,u.city,u.gender,u.email,u.regDate FROM (( ill_history i INNER JOIN Doctors d ON i.byDoctor_id = d.id) 
   INNER JOIN users u ON i.byPatient_id = u.user_signature AND u.user_signature='".$ill."');";
$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$data = array();
while( $rows = mysqli_fetch_assoc($resultset) ) {
$data[] = $rows;
}
return $data;
}
 print_r($items); 


?>