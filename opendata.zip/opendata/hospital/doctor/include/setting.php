<?php
 // some code for import for all .php pages


?>