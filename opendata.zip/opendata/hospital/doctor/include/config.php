<?php
$mysql_hostname = "localhost";
$mysql_user = "root";
$mysql_password = "";
$mysql_database = "opendata";
$bd = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Маълумотлар базасига уланиб бўлмади");
mysql_select_db($mysql_database, $bd) or die("Маълумотлар базасига уланиб бўлмади");

?>