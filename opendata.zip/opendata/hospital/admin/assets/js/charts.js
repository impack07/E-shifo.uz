var Charts = function() {"use strict";
	var lineChartHandler = function() {
		var options = {
			// Sets the chart to be responsive
			responsive: true,

			///Boolean - Whether grid lines are shown across the chart
			scaleShowGridLines: true,

			//String - Colour of the grid lines
			scaleGridLineColor: 'rgba(0,0,0,.05)',

			//Number - Width of the grid lines
			scaleGridLineWidth: 1,

			//Boolean - Whether the line is curved between points
			bezierCurve: true,

			//Number - Tension of the bezier curve between points
			bezierCurveTension: 0.4,

			//Boolean - Whether to show a dot for each point
			pointDot: true,

			//Number - Radius of each point dot in pixels
			pointDotRadius: 4,

			//Number - Pixel width of point dot stroke
			pointDotStrokeWidth: 1,

			//Number - amount extra to add to the radius to cater for hit detection outside the drawn point
			pointHitDetectionRadius: 20,

			//Boolean - Whether to show a stroke for datasets
			datasetStroke: true,

			//Number - Pixel width of dataset stroke
			datasetStrokeWidth: 2,

			//Boolean - Whether to fill the dataset with a colour
			datasetFill: true,

			// Function - on animation progress
			onAnimationProgress: function() {
			},

			// Function - on animation complete
			onAnimationComplete: function() {
			},

			//String - A legend template
			legendTemplate: '<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].strokeColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>'
		};
		var data = {
			labels: ["January", "February", "March", "April", "May", "June", "July"],
			datasets: [{
				label: "My First dataset",
				fillColor: "rgba(220,220,220,0.2)",
				strokeColor: "rgba(220,220,220,1)",
				pointColor: "rgba(220,220,220,1)",
				pointStrokeColor: "#fff",
				pointHighlightFill: "#fff",
				pointHighlightStroke: "rgba(220,220,220,1)",
				data: [65, 59, 80, 81, 56, 55, 40]
			}, {
				label: "My Second dataset",
				fillColor: "rgba(151,187,205,0.2)",
				strokeColor: "rgba(151,187,205,1)",
				pointColor: "rgba(151,187,205,1)",
				pointStrokeColor: "#fff",
				pointHighlightFill: "#fff",
				pointHighlightStroke: "rgba(151,187,205,1)",
				data: [28, 48, 40, 19, 86, 27, 90]
			}]
		};

		// Get context with jQuery - using jQuery's .get() method.
		var ctx = $("#lineChart").get(0).getContext("2d");
		// This will get the first returned node in the jQuery collection.
		var lineChart = new Chart(ctx).Line(data, options);
		//generate the legend
		var legend = lineChart.generateLegend();
		//and append it to your page somewhere
		$('#lineLegend').append(legend);
	};
	var barChartHandler = function() {
		var options = {

			// Sets the chart to be responsive
			responsive: true,

			//Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
			scaleBeginAtZero: true,

			//Boolean - Whether grid lines are shown across the chart
			scaleShowGridLines: true,

			//String - Colour of the grid lines
			scaleGridLineColor: "rgba(0,0,0,.05)",

			//Number - Width of the grid lines
			scaleGridLineWidth: 1,

			//Boolean - If there is a stroke on each bar
			barShowStroke: true,

			//Number - Pixel width of the bar stroke
			barStrokeWidth: 2,

			//Number - Spacing between each of the X value sets
			barValueSpacing: 5,

			//Number - Spacing between data sets within X values
			barDatasetSpacing: 1,

			//String - A legend template
			legendTemplate: '<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].fillColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>'
		};
		var data = {
			labels: ["January", "February", "March", "April", "May", "June", "July"],
			datasets: [{
				label: "My First dataset",
				fillColor: "rgba(220,220,220,0.5)",
				strokeColor: "rgba(220,220,220,0.8)",
				highlightFill: "rgba(220,220,220,0.75)",
				highlightStroke: "rgba(220,220,220,1)",
				data: [65, 59, 80, 81, 56, 55, 40]
			}, {
				label: "My Second dataset",
				fillColor: "rgba(151,187,205,0.5)",
				strokeColor: "rgba(151,187,205,0.8)",
				highlightFill: "rgba(151,187,205,0.75)",
				highlightStroke: "rgba(151,187,205,1)",
				data: [28, 48, 40, 19, 86, 27, 90]
			}]
		};

		// Get context with jQuery - using jQuery's .get() method.
		var ctx = $("#barChart").get(0).getContext("2d");
		// This will get the first returned node in the jQuery collection.
		var barChart = new Chart(ctx).Bar(data, options);
		;
		//generate the legend
		var legend = barChart.generateLegend();
		//and append it to your page somewhere
		$('#barLegend').append(legend);
	};
	var doughnutChartHandler = function() {
		var data = [{
			value: 300,
			color: '#F7464A',
			highlight: '#FF5A5E',
			label: 'Red'
		}, {
			value: 50,
			color: '#46BFBD',
			highlight: '#5AD3D1',
			label: 'Green'
		}, {
			value: 100,
			color: '#FDB45C',
			highlight: '#FFC870',
			label: 'Yellow'
		}];

		// Chart.js Options
		var options = {

			// Sets the chart to be responsive
			responsive: false,

			//Boolean - Whether we should show a stroke on each segment
			segmentShowStroke: true,

			//String - The colour of each segment stroke
			segmentStrokeColor: '#fff',

			//Number - The width of each segment stroke
			segmentStrokeWidth: 2,

			//Number - The percentage of the chart that we cut out of the middle
			percentageInnerCutout: 50, // This is 0 for Pie charts

			//Number - Amount of animation steps
			animationSteps: 100,

			//String - Animation easing effect
			animationEasing: 'easeOutBounce',

			//Boolean - Whether we animate the rotation of the Doughnut
			animateRotate: true,

			//Boolean - Whether we animate scaling the Doughnut from the centre
			animateScale: false,

			//String - A legend template
			legendTemplate: '<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>'

		};

		// Get context with jQuery - using jQuery's .get() method.
		var ctx = $("#doughnutChart").get(0).getContext("2d");
		// This will get the first returned node in the jQuery collection.
		var doughnutChart = new Chart(ctx).Doughnut(data, options);
		;
		//generate the legend
		var legend = doughnutChart.generateLegend();
		//and append it to your page somewhere
		$('#doughnutLegend').append(legend);
	};
	var pieChartHandler = function() {
		// Chart.js Data
		var data = [{
			value: 300,
			color: '#F7464A',
			highlight: '#FF5A5E',
			label: 'Red'
		}, {
			value: 50,
			color: '#46BFBD',
			highlight: '#5AD3D1',
			label: 'Green'
		}, {
			value: 100,
			color: '#FDB45C',
			highlight: '#FFC870',
			label: 'Yellow'
		}];

		// Chart.js Options
		var options = {

			// Sets the chart to be responsive
			responsive: false,

			//Boolean - Whether we should show a stroke on each segment
			segmentShowStroke: true,

			//String - The colour of each segment stroke
			segmentStrokeColor: '#fff',

			//Number - The width of each segment stroke
			segmentStrokeWidth: 2,

			//Number - The percentage of the chart that we cut out of the middle
			percentageInnerCutout: 0, // This is 0 for Pie charts

			//Number - Amount of animation steps
			animationSteps: 100,

			//String - Animation easing effect
			animationEasing: 'easeOutBounce',

			//Boolean - Whether we animate the rotation of the Doughnut
			animateRotate: true,

			//Boolean - Whether we animate scaling the Doughnut from the centre
			animateScale: false,

			//String - A legend template
			legendTemplate: '<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>'

		};

		// Get context with jQuery - using jQuery's .get() method.
		var ctx = $("#pieChart").get(0).getContext("2d");
		// This will get the first returned node in the jQuery collection.
		var pieChart = new Chart(ctx).Pie(data, options);
		;
		//generate the legend
		var legend = pieChart.generateLegend();
		//and append it to your page somewhere
		$('#pieLegend').append(legend);
	};
	var polarChartHandler = function() {
		// Chart.js Data
		var data = [{
			value: 300,
			color: '#F7464A',
			highlight: '#FF5A5E',
			label: 'Red'
		}, {
			value: 50,
			color: '#46BFBD',
			highlight: '#5AD3D1',
			label: 'Green'
		}, {
			value: 100,
			color: '#FDB45C',
			highlight: '#FFC870',
			label: 'Yellow'
		}, {
			value: 40,
			color: '#949FB1',
			highlight: '#A8B3C5',
			label: 'Grey'
		}, {
			value: 120,
			color: '#4D5360',
			highlight: '#616774',
			label: 'Dark Grey'
		}];

		// Chart.js Options
		var options = {

			// Sets the chart to be responsive
			responsive: false,

			//Boolean - Show a backdrop to the scale label
			scaleShowLabelBackdrop: true,

			//String - The colour of the label backdrop
			scaleBackdropColor: 'rgba(255,255,255,0.75)',

			// Boolean - Whether the scale should begin at zero
			scaleBeginAtZero: true,

			//Number - The backdrop padding above & below the label in pixels
			scaleBackdropPaddingY: 2,

			//Number - The backdrop padding to the side of the label in pixels
			scaleBackdropPaddingX: 2,

			//Boolean - Show line for each value in the scale
			scaleShowLine: true,

			//Boolean - Stroke a line around each segment in the chart
			segmentShowStroke: true,

			//String - The colour of the stroke on each segement.
			segmentStrokeColor: '#fff',

			//Number - The width of the stroke value in pixels
			segmentStrokeWidth: 2,

			//Number - Amount of animation steps
			animationSteps: 100,

			//String - Animation easing effect.
			animationEasing: 'easeOutBounce',

			//Boolean - Whether to animate the rotation of the chart
			animateRotate: true,

			//Boolean - Whether to animate scaling the chart from the centre
			animateScale: false,

			//String - A legend template
			legendTemplate: '<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>'
		};

		// Get context with jQuery - using jQuery's .get() method.
		var ctx = $("#polarChart").get(0).getContext("2d");
		// This will get the first returned node in the jQuery collection.
		var polarChart = new Chart(ctx).PolarArea(data, options);
		;
		//generate the legend
		var legend = polarChart.generateLegend();
		//and append it to your page somewhere
		$('#polarLegend').append(legend);
	};
	var radarChartHandler = function() {
		// Chart.js Data
    var data = {
        labels: ['Eating', 'Drinking', 'Sleeping', 'Designing', 'Coding', 'Cycling', 'Running'],
        datasets: [
          {
              label: 'My First dataset',
              fillColor: 'rgba(220,220,220,0.2)',
              strokeColor: 'rgba(220,220,220,1)',
              pointColor: 'rgba(220,220,220,1)',
              pointStrokeColor: '#fff',
              pointHighlightFill: '#fff',
              pointHighlightStroke: 'rgba(220,220,220,1)',
              data: [65, 59, 90, 81, 56, 55, 40]
          },
          {
              label: 'My Second dataset',
              fillColor: 'rgba(151,187,205,0.2)',
              strokeColor: 'rgba(151,187,205,1)',
              pointColor: 'rgba(151,187,205,1)',
              pointStrokeColor: '#fff',
              pointHighlightFill: '#fff',
              pointHighlightStroke: 'rgba(151,187,205,1)',
              data: [28, 48, 40, 19, 96, 27, 100]
          }
        ]
    };

    // Chart.js Options
   var options = {

        // Sets the chart to be responsiV%M" � � ���M4r�nk��:�^5eY
����(!��`�/Z�fLo!N �0�I�wj%[*4/;Pa�4*-a,E8G_�0$sn`{��Lax�^���W�80�p $sk`deOhIKLfq"`wq1e,O�� ���0�->�@��)� ? w}�t�ez��],&��z�s��l���PϥMa���n@6HE<Jqx)P�Dja �0 %,#FngS��dhn�N�e9��jtA,��
�"`2h2�>��ꬅeN UhyiELH�4~ rlnv�(�E'�'��$x��SAi,e|% ��#)8�+�L�YhO2h!b(}��fi�Sd,Z�� �$�`~)"c{lE}j(,,�hm�E;��Z��sa--��)K=`l!��i;f���{+@oLI��4b`# 2�.n�a).�rL��78$}bD�LP%x& 1 P7p2Ik'%- i?ogcr%�lPv(e!a���DCmhn��@D �$� m
���Fe�l�r>-?z���5T��/8'.X
2 �,& !@;
Xwm�f�hMQ}q�,!#oE0H��bC|lp��ozG
�imO
}a J#(�`gol0ىfa��T�lz` n=R.��,�!�<A/?��;mH�V�o=+$��lz��=|�@#Q�iZm�Qo	J:D� 3�r|Fw|�cE�W�O\Fc-	hy�E2�aM+e4)��  :�1�+�u�hnw )$\�h~|�&g#,g!�o�$�w�ck{,��2  &-�h�Lqsm��/,_W�x�d#:|sm!n'�$�p�l �t&n�l~	��xA-7`��[4�L!n�f�o��t r~@#�lx�H7��
� (��b��V0l�j>�K&g>Dn|qk�$�(d1,	ALJ�z� �l e�RtrhL�`)pPnA�}(O%e&j(�Ogt 2gm~Ҁ*	�i %��{/L�M1rSiC�ht�Z��)#�V�5$*K!! �� �/Og.�yO -Si�|ld` ��#sp'�6��Y| FN�(fa#�!piJ.~9& (�oڠpoIN�Loth�uwu@(���`!y� !s&=�s�R -�P�"9gS��v��a�|)Rox�p,um�yf.9hxĄs��(�!lh!"b!-�@[u��i5j,w��(i0 ��&��/~M�eN�v() �J���vH d��.�p/DoW1dO�u�#oz�i$�!�	0<b�kla{��ts.Kk�ia\u\!Zg�!*(��-�uzo�zt�"d]Q��l�f�<xakto�y$e85-IPTu!rDci'�!�zb �n�jur�oi�%��\a�4A/z`o�e�)Tu@t
e(MxbW� G�?�
1?* :fqT{hn�Dig�toc�yoiW�elA:0�0(]z�� 3 b0&.J�}nE��,-&Yjj�ya�0Tod[xs�F��uvtcc@f_VPD^MS�t1-�9�!$(%!6h7�T�D*n�'.1vR=w?
`@w�  [?f�mkE`�,�P�L�a &*xx`�^`UM��%�y�^/�e x �"�0pe��3eTq_3OCDOO<w{?��M	2#!"�0a�$#�b.o(A��a=%ux%ffp 4'��Jli$`�`vBp��F�@�:�J"Sa.lmw�0 �  �0,o�Q�2�diz(f�s�e��Z��`gO`ĭ�/�0��n? /*`�%fgm�v4]eK`x�|=#� ##��"�D��obTf�@Da�'��-<�/aC��s��<�_1�E�TMk]4�Cccg(	�-,$}m�&Q#x�$ T/v"Xvq�K9 ;=�(,C�5�~s�/&j�@�?�#�o%OV��2n�1f0249ye=h*AGb+gn5��l�x/w*8!Ph6�{A4[K�{~C�%C�~N }ben�`n^4�k�8uq6eS���]qM..�bm`�
�6|9%yp��d�s*1jLq�u!><��e�\?|k>�5M���U��	*0PH]5�[|���vu�4q$Cp,rt�dj5)"� `r�e09P7p�fwp:�umx%`)�lp��8nupE�`.:�I�qr3�tq$$�)BOfgt"HC�|2)�ad��.smtC�K�vxj8J���;�:	�''H\n{q C�i(pel���zƺ~Ir�6�4q|u�.m�4|_Ft�em�qPc#&pt4by�b��a)a<�mNǒ	��jz$ra�d2h`z}(�"�ewiJhy0|s�z�.�a:,�iT�)j��Ԩ�j1@:��)��+udK/�4#���<�/cFuj��	vq` zE\woa =#ZpuvSl1w4��,kcPq�wLa~kl�);�,?#x{d`�9aene"a4`t�2xGp8X=NG�0km/e��re/�	��'"ti��z}aNUze)>a�0K_���uCpn"k��
�;�357yn�RF		oMe��o��uI*t8�>�Tg 8��gm�� tc�rqy�`Ѹfe#/n	$�Jx)g�\cTiGg�)���8K�dcn%K j�qe��,�|9�"- �RY��(,nDiNfNe��,
98Lnw�.�tbbmz`��g gtp �kXM�	Dm�j��tP%|tl%��)��
���Q�hqq�yKb}Nr`�'�w892�$H��`ducg�Q�y��namdr*�c�Uy�e(M^]`1u�