<?php
  // http://localhost/opendata/hospital_1/hospital/readAllDoctor.php?reg=".." &spec="...";
header("Content-Type:application/json");
include_once("baza.php");

if(isset($_GET['reg']) && !empty($_GET['reg']) && isset($_GET['spec']) && !empty($_GET['spec'])){
    			$region=$_GET['reg'];
				$spec=$_GET['spec'];
				$items = getItems($region,$spec, $conn);
			if(empty($items)) 
				{
				jsonResponse(200,"Items Not Found",NULL);
				} 
			else 
				{
				jsonResponse(200,"Item Found",$items);
				}

} 
else if(isset($_GET['reg']) && !empty($_GET['reg']) && empty($_GET['spec'])){
    			$region=$_GET['reg'];
				$spec='1';
				$items = getItems($region,$spec, $conn);
			if(empty($items)) 
				{
				jsonResponse(200,"Items Not Found",NULL);
				} 
			else 
				{
				jsonResponse(200,"Item Found",$items);
				}

  } 
		else  if(isset($_GET['spec']) && !empty($_GET['spec']) && empty($_GET['reg'])){
    			$spec=$_GET['spec'];
				$region='1';
				$items = getItems($region,$spec, $conn);
			if(empty($items)) 
				{
				jsonResponse(200,"Items Not Found",NULL);
				} 
			else 
				{
				jsonResponse(200,"Item Found",$items);
				}

  } 
  else  if(empty($_GET['spec']) && empty($_GET['reg'])){
    			$spec='1';
				$region='1';
				$items = getItems($region,$spec, $conn);
			if(empty($items)) 
				{
				jsonResponse(200,"Items Not Found",NULL);
				} 
			else 
				{
				jsonResponse(200,"Item Found",$items);
				}

  } 


else {
jsonResponse(400,"Invalid Request",NULL);
}
function jsonResponse($status,$status_message,$data) {
header("HTTP/1.1 ".$status_message);
$response['status']=$status;
$response['status_message']=$status_message;
$response['data']=$data;
$json_response = json_encode($response);
echo $json_response;
}
function getItems($region,$spec, $conn) {

	if($spec=='1'){
			$sql = "SELECT * FROM doctors  WHERE address='".$region."'";
	}
	if($region=='1'){
			$sql = "SELECT * FROM doctors  WHERE specilization='".$spec."'";
	}

	if($region=='1' && $spec=='1' ){
			$sql = "SELECT * FROM doctors ";
	}

	else if ($region!='1' && $spec!='1' )
			{
				$sql = "SELECT * FROM doctors WHERE address='".$region."' AND specilization='".$spec."'";
			}

	


	

$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
$data = array();
while( $rows = mysqli_fetch_assoc($resultset) ) {
$data[] = $rows;
}
return $data;
}
 print_r($items); 


?>