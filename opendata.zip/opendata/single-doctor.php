<!doctype html>
<!--[if IE 7]>    <html class="ie7" > <![endif]-->
<!--[if IE 8]>    <html class="ie8" > <![endif]-->
<!--[if IE 9]>    <html class="ie9" > <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en-US"> <!--<![endif]-->
		<head>				
				<!-- META TAGS -->
				<meta charset="UTF-8" />
				<meta name="viewport" content="width=device-width" />
				
				<!-- Title -->
				<title>Health Press</title>
              
                <!-- FAVICON -->
                <link rel="shortcut icon" href="temp_class/images/favicon.png.png" />
				
                
                <!-- Style Sheet-->
				<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,800,700,300' rel='stylesheet' type='text/css'>
				<link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>                  
                <link rel="stylesheet" href="temp_class/js/prettyPhoto/css/prettyPhoto.css"/>
                <link rel="stylesheet" href="temp_class/js/flexslider/flexslider.css"/>                
                <link rel="stylesheet" href="temp_class/css/jquery.ui.all.css"/>                
                <link rel="stylesheet" href="temp_class/css/jquery.ui.theme.css"/> 
				<link rel="stylesheet" href="temp_class/css/font-awesome.min.css"/> 				<link rel="stylesheet" href="style.css"/>
                <link rel="stylesheet" href="temp_class/css/media-queries.css"/>                    
                <link rel="stylesheet" href="temp_class/css/custom.css"/>                     
                
                <!-- Pingback URL -->
                <link rel="pingback" href="http://healthpress.inspirythemes.com/xmlrpc.php" />

                <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
                <!--[if lt IE 9]>
                    <script src="js/html5.js"></script>
                <![endif]-->
				
		</head>
        
        <body>				
        
				<!-- Starting Website Wrapper -->
                <div id="wrapper">
                		
                        <!-- Starting Header of the website -->
                        <?php include('header.php');?>
                        
                                           
                        
                        <hgroup class="page-head">                                    		
                                <h2>Dr.Kylee <span>Leewan</span></h2>
                                <h3 class="education">MD, Gyne</h3>
                                <h5>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</h5>                                
                        </hgroup>
                        
                        <div id="container" class="clearfix">
                                <div id="content" class="doctor-page">
										<article id="post-example" class="hentry clearfix">
											<div class="doctor-img">													
                                                <a href="temp_class/images/Refined/d5.jpg" title="Dr.Kylee Leewan" class="pretty-photo"><img class="img-border" src="temp_class/images/Refined/d5.jpeg" alt="Dr.Kylee Leewan"></a>      
                                                <a href="https://twitter.com/#!/envato" class="twitter"><i class="fa fa-twitter"></i></a>
                                                <a href="http://www.facebook.com/envato" class="facebook"><i class="fa fa-facebook"></i></a>
											</div>

                                            <h4>Royal Prince Alfred Hospital – Sydney</h4>
                                            <h5>June 2009 to July 2010</h5>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. Lorem ipsum dolor sit amet, consectetur adipisicing elit,</p>
                                            <h4>Royal Melbourne Hospital -Melbourne</h4>
                                            <h5>Aug 2010 to July 2011</h5>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. Lorem ipsum dolor sit amet, consectetur adipisicing elit,</p>
                                            <h4>St Vincents Hospital – Sydney</h4>
                                            <h5>Aug 2011 to Present</h5>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. Lorem ipsum dolor sit amet, consectetur adipisicing elit,</p>
                                            <h3>Expertise</h3>
                                            <h5>Medicine</h5>
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>
                                            <h5>Gyne</h5>
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>																					
                                            
										</article>	
                                  </div>
                                
                                <aside id="sidebar">
                                    
                                     
                                    
                                                
                                    
                                            
                                    
                                    
                                    <section class="widget">                   
                                                <div class="appointment">
                                                    <div class="header">
                                                            <h2>Make an Appointment</h2>
                                                            <h3 class="number">74 111-11-11</h3>
                                                            <span class="or">OR</span>
                                                    </div>

                                                    <form action="test#" id="appoint-form" method="post">
                                               
                                                     
                                                <a type="submit" href="#" id="nl_submit" value=""class="readmore" >Ro'yxatdan o'tish</a>&nbsp;&nbsp;&nbsp;&nbsp;
                                                
                                                <a type="submit" href="#" id="nl_submit"  class="readmore" width="100">Login</a>
                                                      
                                                        
                                                            
                                                            
                                                            
                                                                                       
                                                    </form>
                                                </div>                             
                                            </section>
                                            								
                                </aside>
                                                                
                                <!-- twitter update list -->
                           
								
                        </div><!-- end of container -->
                        
                       
                                              
                       
                       
                        
						<div id="footer-bottom-wrapper">
                            <div id="footer-bottom">
                                    <p class="copyrights">© OpenData Challenge.</p>
                                     
                            </div><!-- footer-bottom -->
                        </div>
                        
                </div><!-- End of Wrapper Div -->
				
                <script src="temp_class/js/jquery-2.2.3.min.js"></script>
                <script src="temp_class/js/jquery-migrate-1.3.0.js"></script>
                <script src="temp_class/js/prettyPhoto/js/jquery.prettyPhoto.js"></script>                
                <script src="temp_class/js/jquery.validate.min.js"></script>
                <script src="temp_class/js/jquery.form.js"></script>
                <script src="temp_class/js/jquery.ui.core.min.js"></script>
                <script src="temp_class/js/jquery.ui.datepicker.min.js"></script>
                <script src="temp_class/js/jquery.cycle.lite.js"></script>
                <script src="temp_class/js/jquery.easing.1.3.js"></script>
                <script src="temp_class/js/jquery-twitterFetcher.js"></script>
                <script src="temp_class/js/flexslider/jquery.flexslider-min.js"></script>
                <script src="temp_class/js/jquery.isotope.min.js"></script>
                
                <script src="temp_class/js/custom.js"></script>

				<a href="#top" id="scroll-top"></a>
                	
		</body>
</html>