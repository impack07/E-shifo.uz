-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 01, 2018 at 10:24 AM
-- Server version: 5.6.38
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `opendata`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL,
  `updationDate` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'admin', 'test@1234', '28-12-2016 11:42:05 AM');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `doctorSpecialization` varchar(255) CHARACTER SET utf8 NOT NULL,
  `doctorId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `consultancyFees` int(11) NOT NULL,
  `appointmentDate` varchar(255) CHARACTER SET utf8 NOT NULL,
  `appointmentTime` varchar(255) CHARACTER SET utf8 NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userStatus` int(11) NOT NULL,
  `doctorStatus` int(11) NOT NULL,
  `updationDate` varchar(255) CHARACTER SET utf8 NOT NULL,
  `ill_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorSpecialization`, `doctorId`, `userId`, `consultancyFees`, `appointmentDate`, `appointmentTime`, `postingDate`, `userStatus`, `doctorStatus`, `updationDate`, `ill_id`) VALUES
(6, 'Test', 5, 7, 8050, '2018-11-06', '01:11', '2018-11-29 06:55:41', 0, 1, '', 1),
(7, 'Test', 5, 7, 8050, '2018-11-09', '01:13', '2018-11-29 06:56:03', 1, 0, '', 0),
(8, 'Test', 5, 7, 8050, '2018-11-08', '00:22', '2018-11-29 09:25:59', 1, 1, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) CHARACTER SET utf8 NOT NULL,
  `doctorName` varchar(255) CHARACTER SET utf8 NOT NULL,
  `address` longtext CHARACTER SET utf8 NOT NULL,
  `docFees` varchar(255) CHARACTER SET utf8 NOT NULL,
  `contactno` bigint(11) NOT NULL,
  `docEmail` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `specilization`, `doctorName`, `address`, `docFees`, `contactno`, `docEmail`, `password`, `creationDate`, `updationDate`) VALUES
(5, 'test', 'Sanjar', 'Samarqand', '8050', 442166644646, 'u1410008@gmail.com', 'f5f49922d9daa106e50008e1ca1bafb5', '2017-01-07 07:47:07', ''),
(6, 'test 2', 'Jasur', 'Toshkent', '', 0, '', '', '2018-11-30 06:53:21', '');

-- --------------------------------------------------------

--
-- Table structure for table `doctorslog`
--

CREATE TABLE `doctorslog` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `userip` binary(16) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorslog`
--

INSERT INTO `doctorslog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(11, 7, 'test@1234', 0x3a3a3100000000000000000000000000, '2018-11-20 12:35:00', '20-11-2018 05:35:03 PM', 1),
(12, 4, 'test@1234', 0x3a3a3100000000000000000000000000, '2018-11-22 04:16:32', '', 1),
(13, 4, 'test@1234', 0x3a3a3100000000000000000000000000, '2018-11-29 06:13:53', '29-11-2018 11:14:13 AM', 1),
(14, 4, 'test@1234', 0x3a3a3100000000000000000000000000, '2018-11-29 07:12:35', '29-11-2018 12:13:56 PM', 1),
(15, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 07:14:02', '29-11-2018 12:23:16 PM', 1),
(16, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 07:24:31', '29-11-2018 12:26:03 PM', 1),
(17, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 07:27:52', '29-11-2018 02:24:58 PM', 1),
(18, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 09:26:45', '29-11-2018 02:29:59 PM', 1),
(19, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 09:32:07', '29-11-2018 03:13:13 PM', 1),
(20, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 10:14:55', '29-11-2018 06:48:13 PM', 1),
(21, 0, 'test@1234', 0x3a3a3100000000000000000000000000, '2018-11-30 05:21:04', '', 0),
(22, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-30 05:21:17', '', 1),
(23, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-12-01 07:17:47', '01-12-2018 12:17:53 PM', 1),
(24, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-12-01 07:19:11', '01-12-2018 12:19:13 PM', 1),
(25, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-12-01 07:19:55', '01-12-2018 12:19:57 PM', 1),
(26, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-12-01 07:21:45', '01-12-2018 12:21:47 PM', 1),
(27, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-12-01 07:22:13', '01-12-2018 12:22:24 PM', 1),
(28, 5, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-12-01 07:22:31', '01-12-2018 12:22:46 PM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctorspecilization`
--

CREATE TABLE `doctorspecilization` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) CHARACTER SET utf8 NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorspecilization`
--

INSERT INTO `doctorspecilization` (`id`, `specilization`, `creationDate`, `updationDate`) VALUES
(1, 'Ginekolog / ', '2016-12-28 06:37:25', '30-11-2018 11:05:32 AM'),
(2, 'Umumiy shifokor', '2016-12-28 06:38:12', ''),
(3, 'Dermatolog', '2016-12-28 06:38:48', ''),
(4, 'Quloq', '2016-12-28 06:39:26', ''),
(5, 'Test', '2016-12-28 06:39:51', ''),
(6, 'Tish shifokori', '2016-12-28 06:40:08', ''),
(7, 'Burun-burun tomog\'i mutaxassisi', '2016-12-28 06:41:18', ''),
(9, 'Demo test', '2016-12-28 07:37:39', '28-12-2016 01:28:42 PM'),
(10, 'Suyaklar mutaxassisi demoni', '2017-01-07 08:07:53', '07-01-2017 01:38:04 PM');

-- --------------------------------------------------------

--
-- Table structure for table `ill_history`
--

CREATE TABLE `ill_history` (
  `id` int(11) NOT NULL,
  `post_date` varchar(255) NOT NULL,
  `ill_text` text NOT NULL,
  `ill_type` varchar(255) NOT NULL,
  `byDoctor_id` varchar(255) NOT NULL,
  `byPatient_id` varchar(255) NOT NULL,
  `treat_time` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ill_history`
--

INSERT INTO `ill_history` (`id`, `post_date`, `ill_text`, `ill_type`, `byDoctor_id`, `byPatient_id`, `treat_time`) VALUES
(8, '22/11/2018', 'test ', '1', '5', '73061fb4a69714f2c37a0fef888365cb', '2018-11-07'),
(9, '29/11/2018', 'qwieuqwie', '2', '5', '73061fb4a69714f2c37a0fef888365cb', '2018-11-07'),
(10, '30/11/2018', 'wewtwetwet', '1', '5', '73061fb4a69714f2c37a0fef888365c', '2018-11-05');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8 NOT NULL,
  `userip` binary(16) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(29, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 06:33:17', '29-11-2018 12:08:01 PM', 1),
(30, 0, 'test@1234', 0x3a3a3100000000000000000000000000, '2018-11-29 07:08:14', '', 0),
(31, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 07:08:22', '29-11-2018 12:12:21 PM', 1),
(32, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 07:23:44', '29-11-2018 12:24:17 PM', 1),
(33, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 07:26:12', '29-11-2018 12:27:21 PM', 1),
(34, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 09:25:25', '29-11-2018 02:26:30 PM', 1),
(35, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 09:30:08', '29-11-2018 02:31:56 PM', 1),
(36, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-29 10:13:24', '29-11-2018 03:14:43 PM', 1),
(37, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-30 04:11:52', '', 1),
(38, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-11-30 12:36:54', '30-11-2018 05:37:37 PM', 1),
(39, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-12-01 05:43:45', '01-12-2018 10:44:13 AM', 1),
(40, 7, 'u1410008@gmail.com', 0x3a3a3100000000000000000000000000, '2018-12-01 07:23:07', '01-12-2018 12:23:10 PM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) CHARACTER SET utf8 NOT NULL,
  `address` longtext CHARACTER SET utf8 NOT NULL,
  `city` varchar(255) CHARACTER SET utf8 NOT NULL,
  `gender` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) CHARACTER SET utf8 NOT NULL,
  `user_signature` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `address`, `city`, `gender`, `email`, `password`, `regDate`, `updationDate`, `user_signature`) VALUES
(7, 'Azimjonov Shoxruxbek ', 'Andijon viloyati', 'Andijon tumani', 'male', 'u1410008@gmail.com', 'f5f49922d9daa106e50008e1ca1bafb5', '2018-11-29 06:32:48', '', '73061fb4a69714f2c37a0fef888365cb');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorslog`
--
ALTER TABLE `doctorslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ill_history`
--
ALTER TABLE `ill_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `doctorslog`
--
ALTER TABLE `doctorslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `ill_history`
--
ALTER TABLE `ill_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
