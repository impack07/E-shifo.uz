<!doctype html>
<!--[if IE 7]>    <html class="ie7" > <![endif]-->
<!--[if IE 8]>    <html class="ie8" > <![endif]-->
<!--[if IE 9]>    <html class="ie9" > <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en-US"> <!--<![endif]-->
		<head>				
				<!-- META TAGS -->
				<meta charset="UTF-8" />
				<meta name="viewport" content="width=device-width" />
				
				<!-- Title -->
				<title>Health Press</title>
              
                <!-- FAVICON -->
                <link rel="shortcut icon" href="temp_class/images/favicon.png.png" />
				
                
                <!-- Style Sheet-->
				<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,800,700,300' rel='stylesheet' type='text/css'>
				<link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>                  
                <link rel="stylesheet" href="temp_class/js/prettyPhoto/css/prettyPhoto.css"/>
                <link rel="stylesheet" href="temp_class/js/flexslider/flexslider.css"/>                
                <link rel="stylesheet" href="temp_class/css/jquery.ui.all.css"/>                
                <link rel="stylesheet" href="temp_class/css/jquery.ui.theme.css"/> 
				<link rel="stylesheet" href="temp_class/css/font-awesome.min.css"/> 				<link rel="stylesheet" href="style.css"/>
                <link rel="stylesheet" href="temp_class/css/media-queries.css"/>                    
                <link rel="stylesheet" href="temp_class/css/custom.css"/>                     
                
                <!-- Pingback URL -->
                <link rel="pingback" href="http://healthpress.inspirythemes.com/xmlrpc.php" />

                <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
                <!--[if lt IE 9]>
                    <script src="js/html5.js"></script>
                <![endif]-->
				
		</head>
        
        <body>				
        
				<!-- Starting Website Wrapper -->
                <div id="wrapper">
                		
                        <!-- Starting Header of the website -->
                        <?php include('header.php');?>
                        
                        
                        
                        <hgroup class="page-head">    		
                                <h2>Contact <span>Us</span></h2>
                                <h5>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh<br> euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</h5>
                        </hgroup>
                        
                       <div id="container" class="clearfix">
								
                                <div id="content">
                                		                                                   
                                     																                                                        
                                    
                                                                       
                                        <div class="contact-form-container">
                                            <h3 class="smart-head">Contact Us</h3>
                                            <p>Fill out the form below to send us a message and we will get back to you ASAP.</p>
                                            <form action="submit.php" id="contact-form" class="clearfix" method="post">
                                                <div class="form-cell">
                                                    <label class="display-ie8" >Name:</label>
                                                	<input type="text" placeholder="Name" class="name required" name="author" title="* Please provide your name"  /><span>*</span>
                                                </div>
                                                
                                                <div class="form-cell">
                                                     <label class="display-ie8" >Phone:</label>
                                                	<input type="text" placeholder="Phone No." class="phone" name="phone" />
                                                </div>
                                                
                                                <div class="form-cell">
                                                     <label class="display-ie8" >Email:</label>
                                                	<input type="text" placeholder="Email Address'" class="email required" name="email" title="* Please enter your email address" /><span>*</span>
                                                </div>
                                                
                                                <div class="form-cell">
                                                     <label class="display-ie8" >Subject:</label>
                                                	<input type="text" placeholder="Subject" class="subject" name="subject" />
                                                </div>																								
                                                
                                                <div class="form-row">
                                                     <label class="display-ie8" >Message:</label>
                                                	<textarea name="message" class="message required" cols="30" rows="10" placeholder="Message" title="* Please enter your message"></textarea>
													
													<div class="captcha-container">
														<label>Are you human?</label>
														<img src="#" alt="captcha"/>
														<input type="text" class="captcha required" name="captcha" maxlength="5" title="* Please enter the code characters displayed in image!"/>
													</div>
													
                                                	<input type="submit" name="submit" value="Submit" class="submit readmore"/>
                                                    
                                                    <input type="hidden" name="action" value="send_message" />
													<input type="hidden" name="target" value="fahid@960development.com" />
													<img src="temp_class/images/loading.gif" id="contact-loader" alt="Loader" />
                                                    <p id="message-sent">&nbsp;</p>

                                                </div>
                                                
                                                <div class="error-container">
                                                </div>
                                            </form>
                                        </div>									
                                </div>
                                
                               <aside id="sidebar">
                                    <section class="widget"><br><br><br><br>
                                        <h3 class="title">Quick Contact</h3>        
                                        <div class="contact-widget">
                                            <p>
                                                <strong>Work :</strong> +xxx xxx xx xx <br>
                                                <strong>Cell :</strong>+xxx xxx xx xx<br>
                                                <strong>Fax :</strong> +xxx xxx xx xx<br>
                                            </p>
                                            <hr>
                                            <p>
                                                <a href="#">info@yoursite.com</a><br>
                                                <a href="#">support@yoursite.com</a>            
                                            </p>
                                        </div>        
                                    </section>
                                                                    
                                    							
                                </aside>                               
                                                                
                                								
                                <!-- twitter update list -->
                              

                        </div><!-- end of container -->
                        
                       
                                              
                       
                      
                        
						<div id="footer-bottom-wrapper">
                            <div id="footer-bottom">
                                    <p class="copyrights">© OpenData Challenge.</p>
                                     
                            </div><!-- footer-bottom -->
                        </div>
                        
                </div><!-- End of Wrapper Div -->
				
                <script src="temp_class/js/jquery-2.2.3.min.js"></script>
                <script src="temp_class/js/jquery-migrate-1.3.0.js"></script>
                <script src="temp_class/js/prettyPhoto/js/jquery.prettyPhoto.js"></script>                
                <script src="temp_class/js/jquery.validate.min.js"></script>
                <script src="temp_class/js/jquery.form.js"></script>
                <script src="temp_class/js/jquery.ui.core.min.js"></script>
                <script src="temp_class/js/jquery.ui.datepicker.min.js"></script>
                <script src="temp_class/js/jquery.cycle.lite.js"></script>
                <script src="temp_class/js/jquery.easing.1.3.js"></script>
                <script src="temp_class/js/jquery-twitterFetcher.js"></script>
                <script src="temp_class/js/flexslider/jquery.flexslider-min.js"></script>
                <script src="temp_class/js/jquery.isotope.min.js"></script>
                
                <script src="temp_class/js/custom.js"></script>

				<a href="#top" id="scroll-top"></a>
                	
		</body>
</html>	


