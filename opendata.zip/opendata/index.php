

<!doctype html>
<!--[if IE 7]>    <html class="ie7" > <![endif]-->
<!--[if IE 8]>    <html class="ie8" > <![endif]-->
<!--[if IE 9]>    <html class="ie9" > <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en-US"> <!--<![endif]-->
		<head>				
				<!-- META TAGS -->
				<meta charset="UTF-8" />
				<meta name="viewport" content="width=device-width" />
				
				<!-- Title -->
				<title>E-Health</title>
              
                <!-- FAVICON -->
                <link rel="shortcut icon" href="temp_class/images/favicon.png.png" />
				
                
                <!-- Style Sheet-->
				<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,800,700,300' rel='stylesheet' type='text/css'>
				<link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>                  
                <link rel="stylesheet" href="temp_class/js/prettyPhoto/css/prettyPhoto.css"/>
                <link rel="stylesheet" href="temp_class/js/flexslider/flexslider.css"/>                
                <link rel="stylesheet" href="temp_class/css/jquery.ui.all.css"/>                
                <link rel="stylesheet" href="temp_class/css/jquery.ui.theme.css"/> 
				<link rel="stylesheet" href="temp_class/css/font-awesome.min.css"/>
         				<link rel="stylesheet" href="style.css"/>
                <link rel="stylesheet" href="temp_class/css/media-queries.css"/>                    
                <link rel="stylesheet" href="temp_class/css/custom.css"/>                     
                
                <!-- Pingback URL -->
                <link rel="pingback" href="http://healthpress.inspirythemes.com/xmlrpc.php" />

                <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
                <!--[if lt IE 9]>
                    <script src="js/html5.js"></script>
                <![endif]-->
				
		</head>
        
        <body>				
        
				<!-- Starting Website Wrapper -->
                <div id="wrapper">
                		
                        <!-- Starting Header of the website -->
                        <header id="header">

                                <!-- Website Logo Place -->
                                <div id="logo-container">
                                    <a href="index.php" class="logo"  title="Site Logo">
                                        
                                        <span class="tagline"><h1>Open Data Challenge</h1></span>
                                    </a>
                                </div>
                                                             
                                <ul class="social-nav">                                        
                                    <li class="facebook"><a target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li class="twitter"><a target="_blank" href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li class="skype"><a target="_blank" href="#"><i class="fa fa-skype"></i></a></li>
                                   <li class="flickr"><a target="_blank" href="#"><i class="fa fa-flickr"></i></a></li>
                                    <li class="google"><a target="_blank" href="#"><i class="fa fa-google"></i></a></li>
                                    <li class="linkedin"><a target="_blank" href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li class="rss"><a target="_blank" href="#"><i class="fa fa-rss"></i></a></li>
                                    <li class="phone" ><a type="submit" href="hospital/doctor/" class="img-hover" id="nl_submit"  ><i class="fa fa-sign-in">&nbsp;</i>Doctor Login</a>
                                    </li>
                                </ul>
								
                                
                                <nav class="main-nav clearfix">

                                		<!-- MAIN NAVIGATION -->
                                        <div class="menu-div">
                                        	<ul>
                                            	<li>
                                                	<a href="index.php">Bosh sahifa</a>
                                                   
                                                </li>
                                                
                                                <li>
                                                	<a href="doctors-four-columns.php">Shifokorlar</a>
                                                    
                                                </li>
                                              
                                                <li>
                                                	<a href="four-columns-gallery.php">Galereya</a>
                                                    
                                                </li>
                                               
                                                
                                               <li><a href="contact.php">Biz bilan aloqa</a></li>
                                            </ul>
                                        </div>
                                        
                                        <!-- GLOBAL SEARCH -->
                                        <form method="get" action="#" id="topsearch">
                                        		<p>
                                                    <input type="text" placeholder="Search" name="s" id="tsearch">
                                                    <input type="submit" id="topsubmit" value="">                                                     <i class="fa fa-search"></i>
                                                </p>
                                        </form>
                                </nav>
                        </header><!-- ending of header of the website -->
                        
						<div id="slider-wrap">
                        		<div class="flexslider">
                                    <ul class="slides">                                        		
                                            <li>
                                                <a href="#" title="Malakali Shifokorlar"  class="img-hover" ><img src="temp_class/images/Refined/doctors.jpeg" alt="Slider Image"></a>
                                            </li>
                                            <li>
                                                <a href="#" title="Shifoxonamiz afzalliklari"  class="img-hover" ><img src="temp_class/images/Refined/clinical.jpeg" alt="Slider Image"></a>
                                            </li>
                                            <li>
                                                <a href="#" title="Tish muolajasi"  class="img-hover" ><img src="temp_class/images/Refined/dental.jpeg" alt="Slider Image"></a>
                                            </li>
                                            <li>
                                                <a href="#" title="Xodimlar"  class="img-hover" ><img src="temp_class/images/Refined/caring-staff.jpeg" alt="Slider Image"></a>
                                            </li>
                                            <li>
                                                <a href="#" title="Maslahatlar"  class="img-hover" ><img src="temp_class/images/Refined/couseling.jpeg" alt="Slider Image"></a>
                                            </li>
                                    </ul>
                                    <ul class="slide-nav slides-5">
                                            <li>
                                                <h4>Malakali Shifokorlar</h4>
                                                <p>Tajribali shifokorlar jamoasi</p>
                                            </li> 
                                            <li>
                                                <h4>Shifoxonamiz afzalliklari</h4>
                                                <p>Yuqori malakali xodimlar</p>
                                            </li> 
                                            <li>
                                                <h4>Tish Muolajasi</h4>
                                                <p>Yuqori darajadagi tishlar muolajasi</p>
                                            </li> 
                                            <li>
                                                <h4>Xodimlar</h4>
                                                <p>E`tiborli xodimlar</p>
                                            </li> 
                                            <li>
                                                <h4>Maslahatlar</h4>
                                                <p>Expertlar maslahatlari</p>
                                            </li>                                            
                                    </ul><!-- end of slider nav -->
                        		</div>
                        </div><!-- end of slider-wrap -->
                        
                        <div id="container">
                        		
                                <section class="slogan">
                                    <h2>Tibbiy Xizmatlar</h2>
                                    </section>
                                
                                <ul class="services">                                        
                                      <li class="service">
                                          <figure class="service-thumb"><a href="#"><img src="temp_class/images/Refined/small/serv1.png" alt="Diagnostic Imaging"></a></figure>
                                          <h4>Diagnostika</a></h4>
                                          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                                      </li>
                                      <li class="service">
                                          <figure class="service-thumb"><a href="#"><img src="temp_class/images/Refined/small/serv2.png" alt="Cancer Care"></a></figure>
                                          <h4>Nevrologiya</a></h4>
                                          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                                      </li>
                                      <li class="service">
                                          <figure class="service-thumb"><a href="#"><img src="temp_class/images/Refined/small/serv3.png" alt="Rehabilitation Center"></a></figure>
                                          <h4>Terapiya</a></h4>
                                          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                                      </li>
                                      <li class="service">
                                          <figure class="service-thumb"><a href="#"><img src="temp_class/images/Refined/small/serv4.png" alt="Emergency Services"></a></figure>
                                          <h4>Tez tibbiy yordam</a></h4>
                                          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                                      </li>
                                      <li class="service">
                                          <figure class="service-thumb"><a href="#"><img src="temp_class/images/Refined/small/serv5.png" alt="Transplant Services"></a></figure>
                                          <h4>Yurak kasalliklari</a></h4>
                                          <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
                                      </li>                                               
                                </ul><!-- end of services -->                                                               
                                
                                <div id="content" class="full-width"></div>
                                
                                
                                <div class="official clearfix">
                                		
                                        <div class="home-left-side">                                        
                                            <section class="team clearfix">
                                                    <h2 class="smart-head">Yuqori malakali shifokorlar</h2>
                                                    <p>Tajribali shifokorlarimiz</p>
                                                    
                                                    <ul class="doctors">
                                                        <li>
                                                           <h4><a href="single-doctor.php"></a></h4>
                                                           <figure class="doc-img">													
                                                               <a href="single-doctor.php" title="Dr.Orana Taleebin" ><img src="temp_class/images/Refined/small/d1.png" alt="Slider Image"></a>
                                                               <span class="doc-type">Aziz Abdullaev</span>																																
                                                           </figure>
                                                           <p>Farg`ona viloyati 2-sonli kasalxona bosh shifokori</p>
                                                        </li> 
                                                        <li>
                                                           <h4><a href="single-doctor.php"></a></h4>
                                                           <figure class="doc-img">													
                                                               <a href="single-doctor.php" title="Dr.Adaline Becka" ><img src="temp_class/images/Refined/small/d2.png" alt="Slider Image"></a>
                                                               <span class="doc-type">Sanjar Abdullaev</span>																																
                                                           </figure>
                                                           <p>Qashqadaryo viloyati 4-sonli kasalxona bosh shifokori</p>
                                                        </li>
                                                        <li>
                                                           <h4><a href="single-doctor.php"></a></h4>
                                                           <figure class="doc-img">													
                                                               <a href="single-doctor.php" title="Dr.Andrew Bert" ><img src="temp_class/images/Refined/small/d3.jpg" alt="Slider Image"></a>
                                                               <span class="doc-type">Ra`no Abdurazzoqova</span>																																
                                                           </figure>
                                                           <p>Qoraqalpog`iston Respublikasi 1-sonli kasalxona bosh jarrohi</p>
                                                        </li>                                                                                                     		
                                                    </ul>
                                                    <ul class="doctors">
                                                        <li>
                                                           <h4><a href="single-doctor.php"></a></h4>
                                                           <figure class="doc-img">                                                 
                                                               <a href="single-doctor.php" title="Dr.Orana Taleebin" ><img src="temp_class/images/Refined/small/d4.jpg" alt="Slider Image"></a>
                                                               <span class="doc-type">Jasur Xolmurodov</span>                                                                                                                               
                                                           </figure>
                                                           <p>Guliston shahri 2-sonli kasalxona bolalar shifokori</p>
                                                        </li> 
                                                        <li>
                                                           <h4><a href="single-doctor.php"></a></h4>
                                                           <figure class="doc-img">                                                 
                                                               <a href="single-doctor.php" title="Dr.Adaline Becka" ><img src="temp_class/images/Refined/small/d5.jpg" alt="Slider Image"></a>
                                                               <span class="doc-type">Sherzodbek Malikov</span>                                                                                                                               
                                                           </figure>
                                                           <p>Namangan viloyati 1-sonli kasalxona bosh shifokori</p>
                                                        </li>
                                                        <li>
                                                           <h4><a href="single-doctor.php"></a></h4>
                                                           <figure class="doc-img">                                                 
                                                               <a href="single-doctor.php" title="Dr.Andrew Bert" ><img src="temp_class/images/Refined/small/d6.jpg" alt="Slider Image"></a>
                                                               <span class="doc-type">Javohir Abduqaxorov</span>                                                                                                                                
                                                           </figure>
                                                           <p>Samarqand viloyati 1-sonli kasalxona bosh shifokori</p>
                                                        </li>                                                                                                           
                                                    </ul>
                                                    <a href="#" class="readmore">Boshqalar</a>														
                                            </section>
                                            
                                                                             
                                        </div><!-- home left side -->                                        
                                        
                                        <aside id="sidebar">
                                                                                    
                                            <section class="widget">                   
                                                <div class="appointment">
                                                    <div class="header">
                                                            <h2>Shifokor qabuliga navbat</h2>
                                                           <h3 class="number">97 446-67-58</h3>
                                                            <span class="or"><h3><b>Yoki</b></h3></span>
                                                    </div>

                                                    <form action="test#" id="appoint-form" method="post">
                                               
                                                     
                                                <a type="submit" href="hospital/registration.php" id="nl_submit" value=""class="readmore" >Ro'yxatdan o'tish</a>&nbsp;&nbsp;&nbsp;&nbsp;
                                                
                                                <a type="submit" href="hospital/user-login.php" id="nl_submit"  class="readmore" width="100">Login</a>
                                                      
                                                        
                                                            
                                                            
                                                            
                                                                                       
                                                    </form>
                                                </div>                             
                                            </section>
                                            
                                            <section class="widget"><h3 class="title">Parolni unutdingizmi</h3>       
                                                <div class="newsletter">                  
                                                  <form action="#" id="newsletter" method="post" novalidate>
                                                      <p>Sizning E-mailingiz:</p>
                                                      <p>
                                                          <label class="display-ie8" for="nl_email">Email Address</label>
                                                          <input type="text" name="EMAIL" id="nl_email" class="email required" placeholder="Email Address" title="* Please enter valid Email Address">
                                                          <a type="submit" id="nl_submit"  class="readmore">Yuborish</a>
                                                      </p>
                                                      <div class="error-container"></div>
                                                  </form>
                                                </div>               
                                            </section>									
                                        </aside>                                        
                                                                       
                                </div> <!-- end of official -->
                                
								<!-- twitter update list -->
                               

                        </div><!-- end of container -->
                        
		                       
                                              
                       
                     
                        
						<div id="footer-bottom-wrapper">
							<div id="footer-bottom">
									<p class="copyrights">© OpenData Challenge.</p>
									 
		                    </div><!-- footer-bottom -->
						</div>
                        
                </div><!-- End of Wrapper Div -->
				
                <script src="temp_class/js/jquery-2.2.3.min.js"></script>
                <script src="temp_class/js/jquery-migrate-1.3.0.js"></script>
                <script src="temp_class/js/prettyPhoto/js/jquery.prettyPhoto.js"></script>                
                <script src="temp_class/js/jquery.validate.min.js"></script>
                <script src="temp_class/js/jquery.form.js"></script>
                <script src="temp_class/js/jquery.ui.core.min.js"></script>
                <script src="temp_class/js/jquery.ui.datepicker.min.js"></script>
                <script src="temp_class/js/jquery.cycle.lite.js"></script>
                <script src="temp_class/js/jquery.easing.1.3.js"></script>
                <script src="temp_class/js/jquery-twitterFetcher.js"></script>
                <script src="temp_class/js/flexslider/jquery.flexslider-min.js"></script>
                <script src="temp_class/js/jquery.isotope.min.js"></script>
                
                <script src="temp_class/js/custom.js"></script>

				<a href="#top" id="scroll-top"></a>
                	
		</body>
</html>	