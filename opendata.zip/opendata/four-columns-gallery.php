<!doctype html>
<!--[if IE 7]>    <html class="ie7" > <![endif]-->
<!--[if IE 8]>    <html class="ie8" > <![endif]-->
<!--[if IE 9]>    <html class="ie9" > <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en-US"> <!--<![endif]-->
		<head>				
				<!-- META TAGS -->
				<meta charset="UTF-8" />
				<meta name="viewport" content="width=device-width" />
				
				<!-- Title -->
				<title>Health Press</title>
              
                <!-- FAVICON -->
                <link rel="shortcut icon" href="temp_class/images/favicon.png.png" />
				
                
                <!-- Style Sheet-->
				<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,800,700,300' rel='stylesheet' type='text/css'>
				<link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>                  
                <link rel="stylesheet" href="temp_class/js/prettyPhoto/css/prettyPhoto.css"/>
                <link rel="stylesheet" href="temp_class/js/flexslider/flexslider.css"/>                
                <link rel="stylesheet" href="temp_class/css/jquery.ui.all.css"/>                
                <link rel="stylesheet" href="temp_class/css/jquery.ui.theme.css"/> 
				<link rel="stylesheet" href="temp_class/css/font-awesome.min.css"/> 				<link rel="stylesheet" href="style.css"/>
                <link rel="stylesheet" href="temp_class/css/media-queries.css"/>                    
                <link rel="stylesheet" href="temp_class/css/custom.css"/>                     
                
                <!-- Pingback URL -->
                <link rel="pingback" href="http://healthpress.inspirythemes.com/xmlrpc.php" />

                <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
                <!--[if lt IE 9]>
                    <script src="js/html5.js"></script>
                <![endif]-->
				
		</head>
        
        <body>				
        
				<!-- Starting Website Wrapper -->
                <div id="wrapper">
                		
                        <!-- Starting Header of the website -->
                        <?php include('header.php');?>
                        
                        			
            
            <hgroup class="page-head">		
                    <h2><span>Four</span> Columns Gallery</h2>
                    <h5>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet <br> dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam.</h5>
            </hgroup>
            
            <div id="container" class="clearfix">
                    
                    <div id="content" class="full-width">								
                    
					<ul id="filter-by" class="clearfix">
                        <li><a href="#" data-filter="gallery-item" class="active">All</a></li>
                        <li><a href="#" data-filter="care" title="View all Gallery Items filed under Care">Care</a></li>
                        <li><a href="#" data-filter="donations" title="View all Gallery Items filed under Donations" >Donations</a></li>
                        <li><a href="#" data-filter="pharmacy" title="View all Gallery Items filed under Pharmacy">Pharmacy</a></li>
                        <li><a href="#" data-filter="staff" title="View all Gallery Items filed under Staff">Staff</a></li>
                        <li><a href="#" data-filter="treatment" title="View all Gallery Items filed under Treatment">Treatment</a></li>
                   </ul>
					
					<div id="gallery-container" class="gallery-4-columns isotope clearfix">
									<div class="type-gallery-item hentry gallery-item isotope-item care staff treatment">
                                        <a class="pretty-photo" href="#"><img src="temp_class/images/Refined/gallery/small/g1.jpeg" alt="Staff"></a>
                                        <h5 class="item-title"><a href="#" title="Staff">Staff</a></h5>
                                        <span class="item-type-link"><a href="#">Care</a>, <a href="#">Staff</a>, <a href="#">Treatment</a></span>																							
									</div>						
									<div class="type-gallery-item hentry gallery-item isotope-item care pharmacy treatment">
                                        <a class="pretty-photo" href="#"><img src="temp_class/images/Refined/gallery/small/g2.jpeg" alt="Clinical Experties"></a>
                                        <h5 class="item-title"><a href="#" title="Clinical Experties">Clinical Experties</a></h5>
                                        <span class="item-type-link"><a href="#">Care</a>, <a href="#">Pharmacy</a>, <a href="#">Treatment</a></span>
									</div>						
									<div class="type-gallery-item hentry gallery-item isotope-item care donations">
                                        <a class="pretty-photo" href="#"><img src="temp_class/images/Refined/gallery/small/g3.jpeg" alt="Fitness Guidance"></a>
                                        <h5 class="item-title"><a href="#" title="Fitness Guidance">Fitness Guidance</a></h5>
                                        <span class="item-type-link"><a href="#">Care</a>, <a href="#">Donations</a></span>
									</div>						
									<div class="type-gallery-item hentry gallery-item isotope-item care treatment">
                                        <a class="pretty-photo" href="#"><img src="temp_class/images/Refined/gallery/small/g4.jpeg" alt="Satisfied Patients"></a>
                                        <h5 class="item-title"><a href="#" title="Satisfied Patients">Satisfied Patients</a></h5>
                                        <span class="item-type-link"><a href="#">Care</a>, <a href="#">Treatment</a></span>
									</div>						
									<div class="type-gallery-item hentry gallery-item isotope-item treatment">
                                        <a class="pretty-photo" href="#"><img src="temp_class/images/Refined/gallery/small/g5.jpeg" alt="Dental Treatment"></a>
                                        <h5 class="item-title"><a href="#" title="Dental Treatment">Dental Treatment</a></h5>
                                        <span class="item-type-link"><a href="#">Treatment</a></span>
									</div>						
									<div class="type-gallery-item hentry gallery-item isotope-item donations">
                                        <a class="pretty-photo" href="#"><img src="temp_class/images/Refined/gallery/small/g6.jpeg" alt="Free Counseling"></a>
                                        <h5 class="item-title"><a href="#" title="Free Counseling">Free Counseling</a></h5>
                                        <span class="item-type-link"><a href="#">Donations</a></span>
									</div>						
									<div class="type-gallery-item hentry gallery-item isotope-item donations">
                                        <a class="pretty-photo" href="#"><img src="temp_class/images/Refined/gallery/small/g7.jpeg" alt="Blood Donation"></a>
                                        <h5 class="item-title"><a href="#" title="Blood Donation">Blood Donation</a></h5>
                                        <span class="item-type-link"><a href="#">Donations</a></span>
									</div>
									<div class="type-gallery-item hentry gallery-item isotope-item pharmacy">
                                        <a class="pretty-photo" href="#"><img src="temp_class/images/Refined/gallery/small/g8.jpeg" alt="Pharmacy Reception"></a>
                                        <h5 class="item-title"><a href="#" title="Pharmacy Reception">Pharmacy Reception</a></h5>
                                        <span class="item-type-link"><a href="#">Pharmacy</a></span>
									</div>
																				
					</div><!-- end of gallery container --> 
													
                    </div><!-- end of content -->															                                                             
                                                    
                    <!-- twitter update list -->
                    

                    
            </div><!-- end of container -->
            
                                   
                                              
                       
                    
						<div id="footer-bottom-wrapper">
                            <div id="footer-bottom">
                                    <p class="copyrights">© OpenData Challenge.</p>
                                     
                            </div><!-- footer-bottom -->
                        </div>
                        
                </div><!-- End of Wrapper Div -->
				
                <script src="temp_class/js/jquery-2.2.3.min.js"></script>
                <script src="temp_class/js/jquery-migrate-1.3.0.js"></script>
                <script src="temp_class/js/prettyPhoto/js/jquery.prettyPhoto.js"></script>                
                <script src="temp_class/js/jquery.validate.min.js"></script>
                <script src="temp_class/js/jquery.form.js"></script>
                <script src="temp_class/js/jquery.ui.core.min.js"></script>
                <script src="temp_class/js/jquery.ui.datepicker.min.js"></script>
                <script src="temp_class/js/jquery.cycle.lite.js"></script>
                <script src="temp_class/js/jquery.easing.1.3.js"></script>
                <script src="temp_class/js/jquery-twitterFetcher.js"></script>
                <script src="temp_class/js/flexslider/jquery.flexslider-min.js"></script>
                <script src="temp_class/js/jquery.isotope.min.js"></script>
                
                <script src="temp_class/js/custom.js"></script>

				<a href="#top" id="scroll-top"></a>
                	
		</body>
</html>	