<header id="header">

                                <!-- Website Logo Place -->
                                <div id="logo-container">
                                    <a href="index.php" class="logo"  title="Site Logo">
                                        
                                        <span class="tagline"><h1>Open Data Challenge</h1></span>
                                    </a>
                                </div>
                                                             
                                <ul class="social-nav">                                        
                                    <li class="facebook"><a target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li class="twitter"><a target="_blank" href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li class="skype"><a target="_blank" href="#"><i class="fa fa-skype"></i></a></li>
                                   <li class="flickr"><a target="_blank" href="#"><i class="fa fa-flickr"></i></a></li>
                                    <li class="google"><a target="_blank" href="#"><i class="fa fa-google"></i></a></li>
                                    <li class="linkedin"><a target="_blank" href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li class="rss"><a target="_blank" href="#"><i class="fa fa-rss"></i></a></li>
                                    <li class="phone"><a type="submit" href="hospital/doctor/" class="img-hover" id="nl_submit"  ><i class="fa fa-sign-in">&nbsp;</i>Shifokorlar uchun</a></li>
                                </ul>
                                
                                
                                <nav class="main-nav clearfix">

                                        <!-- MAIN NAVIGATION -->
                                        <div class="menu-div">
                                            <ul>
                                                <li>
                                                    <a href="index.php">Bosh sahifa</a>
                                                   
                                                </li>
                                                
                                                <li>
                                                    <a href="doctors-four-columns.php">Shifokorlar</a>
                                                    
                                                </li>
                                              
                                                <li>
                                                    <a href="four-columns-gallery.php">Galereya</a>
                                                    
                                                </li>
                                               
                                                
                                               <li><a href="contact.php">Biz bilan aloqa</a></li>
                                            </ul>
                                        </div>
                                        
                                        <!-- GLOBAL SEARCH -->
                                        <form method="get" action="#" id="topsearch">
                                                <p>
                                                    <input type="text" placeholder="Search" name="s" id="tsearch">
                                                    <input type="submit" id="topsubmit" value="">                                                     <i class="fa fa-search"></i>
                                                </p>
                                        </form>
                                </nav>
                        </header><!-- ending of header of the website -->